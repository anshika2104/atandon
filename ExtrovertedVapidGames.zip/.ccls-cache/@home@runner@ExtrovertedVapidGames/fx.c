#include <stdio.h>
void sum(){
  int a, b;
  printf("enter two number");
  scanf("%d%d", &a, &b);
  printf("sum is %d", a + b);
}
void main() {
  printf("sum");
  sum();
}
// void sum(int,int);
// void main(){
//   int a,b,r;
//   printf("sum");
//   printf("enter two no");
//   scanf("%d%d",&a,&b);
//   sum(a,b);
// }
// void sum(int a,int b){
//   printf("sum is %d",a+b);
// }
// #include <stdio.h>
// int eveno(int n){
// if(n%2==0){
//     return 1;
// }
// else{
//     return 0;
// }
// }
// int main() {
//     int n, flag;
//     printf("enter the nummber");
//     scanf("%d",&n);
//     flag=eveno(n);
//     if(flag==0)
//     printf("odd");
//     else
//     printf("even");
//     return 0;
// }