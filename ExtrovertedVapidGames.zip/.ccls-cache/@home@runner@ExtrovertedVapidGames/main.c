// #include <stdio.h>

// int main(void) {
//   printf("Hello World\n");
//   return 0;
// }
#include <stdio.h>
int main() {
  // int mynum=15;
  // int m=23;
  // int m=15;
  // mynum=m;

  // mynum=10;
  // printf("%d",m);
  //  int x=5;
  //  int y=7;
  //  int sum=x+y;
  // printf("%d",sum);
  // char myletter='d';
  // printf("my number is %d and my letter is %c",mynum,myletter);
  // printf("my favorite number is:%i",mynum);
  // int x=5,y=7,z=8;
  // printf("%d",x+y+z);
  // int id=12;
  // int age=23;
  // float fee=23.56;
  // char grade='a';
  // printf("student id is %d",id);
  // printf("student age is %d",age);
  // printf("student fee is %f",fee);
  // printf("student grade is %c",grade);
  // const int a=19;
  //   const char b='A';
  //   const float c= 22.33;
  //   printf("const int is %d\n",a);
  //   printf("const char is %c\n",b);
  //   printf("const float is %f\n",c);
  // int r = 5;
  // float area;
  // float C;
  // area = 3.14 * r * r;
  // C = 2 * 3.14 * r;
  // printf("area of circle is %.2f", area);
  // printf("circumference of circle is %.2f", C);
  // float p,r;
  // int t;
  // float SI;
  // printf("enter the value principal");
  // scanf("%f",&p);
  // printf("enter the value of rate ");
  // scanf("%f",&r);
  // printf("enter the value of time");
  // scanf("%d",&t);
  // SI=(p*r*t)/100;
  // printf("the value of si is%.2f",SI);
  // scanf("%.2f",&SI);
  // float c;
  // float feh;
  // printf("enter the value of fehrenheit");
  // scanf("%f",&feh);
  // c=(feh-32)*5/2;
  // printf("the value of celsius is %.2f",c);
  // float a,b,c,d,e;
  // float avg,P;
  //  printf("enter the value of a");
  // scanf("%f",&a);
  // printf("enter the value of b");
  // scanf("%f",&b);
  // printf("enter the value of c");
  // scanf("%f",&c);
  // printf("enter the value of d");
  // scanf("%f",&d);
  // printf("enter the value of e");
  // scanf("%f",&e);
  // avg=(a+b+c+d+e)/5;
  // P=avg*100;
  // printf("the average of 5 subjects is %f",avg);
  // printf("the percentage of 5 subjects is %f",P);
  //   int a=30;
  //   int b=40;

  // //b=a;
  //    a=a+b;
  //   b=a-b;
  // a=a-b;
  //   printf("%d\n",b);
  //   printf("%d",a);
  // char str[10]="program";
  // printf("%d",strlen(str));
  //  printf("%d",str);
  // int i,n,f=0;
  // printf("enter the value of n");
  // scanf("%d",&n);
  // for(i=1;i<=n;i++){
  //   if(n%i==0){
  //     f++;
  //   }
  // }
  // if(f==2){
  //   printf("prime no ");
  //   }
  //   else{
  //     printf("non prime");
  //   }
  // int a=5,b=5,c=10,r;
  // // r=(a==b)&&(c>b);
  // // printf("%d\n",r);
  // // r=(a==b)&&(c<b);
  // // printf("%d\n",r);
  // // r=(a==b)||(c>b);
  // // printf("%d\n",r);
  // // r=(a==b)||(c<b);
  // // printf("%d\n",r);
  // // r=!(a==b)&&(c>b);
  // // printf("%d\n",r);
  // // r=!(a==b);
  // // printf("%d\n",r);
  // // r=!(a!=b)&&(c>b);
  // // printf("%d\n",r);
  // int a=(6*2)+7-9;
  // printf("the arithmetic expression is %d\n",a);
  // int b=10;
  // printf("the rel exp %d",b%2==0);
  // int c=(7>9)&&(5<=9);
  // printf("the logical exp %d\n\",c);
  // int d=(34>7)?1:0;
  // printf("the ternary exp %d\n",d);
  // int e=20;
  // int*addr=&e;
  //  printf("pointer %d\n",addr);
  // int f=10;
  // int shift=10>>1;
  // // printf("bitwise %d\n",shift);
  // int n;
  // float f;
  // char c;
  // printf("enter integer");
  // scanf("%d",&n);
  // while((getchar())!='\n');
  // printf("\n enter float");
  // scanf("%f",&f);
  // int c;
  // printf("enter value");
  // c=getchar();
  // printf("\n you entered");
  // putchar(c);
  // char c[100];
  // printf("enter value");
  // gets(c);
  // printf("\n you entered");
  // puts(c);
  // int x=10;
  // char y='a';
  // x=x+y;
  // float z=x+y;
  // printf("x=%d,z=%f",x,z);
  // int x,y;
  // printf("enter the value of x");
  // scanf("%d",&x);
  // printf("enter the value of y");
  // scanf("%d",&y);
  // if(x>y){
  //   printf("x is greater than y");
  // }
  // if(x<y){
  //   printf("x is less than y");
  // }
  // if(x==y){
  //   printf("x is equal than y");
  // }

  // int num, count, sum = 0;
  // printf("enter +ve no");
  // scanf("%d", &num);
  // for (count = 1; count <= num; ++count) {
  //   sum += count;
  // }
  // printf("sum=%d", sum);
  // int i=1;
  //   while(i<=10){
  //     printf("%d\n",i);
  //     i++;
  //   }
  // int x,ctr;
  // x=0;
  // printf("input no of rows");
  // scanf("%d",&ctr);
  // while(x<ctr){
  //   printf("*");
  //   x++;
  // }
  // int i = 65;
  // do {
  //   printf("%d\n", i);
  //   i++;
  // } while (i <= 71);
  // add number until the user enter zero
  // double n,s=0;
  // do{
  //   printf("enter a no ");
  //   scanf("%lf",&n);
  //   s+=n;
  // }
  //   while(n!=0);
  // printf("s=%.2lf",s);
  // int i, j;
  // for (i = 1; i <= 5; i++) {
  //   for (j = 1; j <= i; j++) {
  //     printf(" * ");
  //   }
  //   printf("\n");
  // }
  // int i = 1, j = 1;
  // while (i <= 3) {
  //   printf("o i%d", i);
  //   while (j <= 3) {
  //     printf("i o%d", j);
  //     j++;
  //   }
  //   i = 1;
  //   i++;
  // }
  //   //nested
  //   dowhile---------------------------------------------------------------------
  //   int i = 1, j;
  //   do {
  //     j = 1;
  //     do {
  //       printf("%d*%d=%d\n", i, j, i * j);
  //       j++;
  //     } while (j <= 10);
  //     i++;
  //   } while (i <= 2);
  //   return 0;
  // }
  //////////////////////////////////////////////////////////////////////////
  // //functions
  //   int sum(int a,int b){
  //     return a+b;
  //   }

  return 0;
}