#include <stdio.h>
// int sum(int a, int b)
// {
//   return a + b;
// }
// int main(void) {
//   int add = sum(10, 30);
//   printf("sum is %d", add);
// void sum();
// void main(){
//   printf("sum");
//   sum();
//}
void sum()
{
  int a, b;
  printf("enter two number");
  scanf("%d%d", &a, &b);
  printf("sum is %d", a + b);
   sum();
  // return 0;
}